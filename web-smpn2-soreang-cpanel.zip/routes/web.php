<?php

use App\Http\Controllers\AbsenHarianController;
use App\Http\Controllers\Admin\BeritaController;
use App\Http\Controllers\Admin\JadwalController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\JamPelajaranController;
use App\Http\Controllers\KelasController;
use App\Http\Controllers\LandingPageController;
use App\Http\Controllers\MapelController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\TahunAjaranController;
use App\Http\Controllers\UserController;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

Route::get('/', [LandingPageController::class, 'index'])->name('welcome');
Route::get('/profil', [LandingPageController::class, 'profil'])->name('profil');
Route::get('/berita', [LandingPageController::class, 'berita'])->name('berita');
Route::get('/galeri', [LandingPageController::class, 'galeri'])->name('galeri');
Route::get('/kontak', [LandingPageController::class, 'kontak'])->name('kontak');

Route::get('/dashboard', [DashboardController::class, 'index'])
    ->middleware(['auth', 'verified'])
    ->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    Route::get('/absen-harian/{absenHarian}/foto', [AbsenHarianController::class, 'foto'])->name('absen-harian.foto');
});

Route::middleware(['auth', 'role:guru,guru_piket'])->group(function () {
    Route::get('/absen-harian', [AbsenHarianController::class, 'index'])->name('absen-harian.index');
    Route::post('/absen-harian', [AbsenHarianController::class, 'store'])->name('absen-harian.store');
    Route::post('/absen-harian/pulang', [AbsenHarianController::class, 'pulang'])->name('absen-harian.pulang');
    Route::post('/absen-harian/daftar-wajah', [AbsenHarianController::class, 'enrollFace'])->name('absen-harian.enroll-face');
});

Route::middleware(['auth', 'role:admin,kepsek'])->group(function () {
    Route::get('/rekap-absen-harian', [AbsenHarianController::class, 'rekap'])->name('absen-harian.rekap');
});

Route::middleware(['auth', 'admin'])->group(function () {
    Route::delete('/rekap-absen-harian/{user}/reset-wajah', [AbsenHarianController::class, 'resetFace'])->name('absen-harian.reset-face');
    Route::get('/users', [UserController::class, 'index'])->name('users.index');
    Route::post('/users', [UserController::class, 'store'])->name('users.store');
    Route::patch('/users/{user}', [UserController::class, 'update'])->name('users.update');
    Route::patch('/users/{user}/toggle-status', [UserController::class, 'toggleStatus'])->name('users.toggle-status');
    Route::delete('/users/{user}', [UserController::class, 'destroy'])->name('users.destroy');

    Route::get('/tahun-ajaran', [TahunAjaranController::class, 'index'])->name('tahun-ajaran.index');
    Route::post('/tahun-ajaran', [TahunAjaranController::class, 'store'])->name('tahun-ajaran.store');
    Route::patch('/tahun-ajaran/{tahunAjaran}', [TahunAjaranController::class, 'update'])->name('tahun-ajaran.update');
    Route::patch('/tahun-ajaran/{tahunAjaran}/aktif', [TahunAjaranController::class, 'activate'])->name('tahun-ajaran.activate');
    Route::delete('/tahun-ajaran/{tahunAjaran}', [TahunAjaranController::class, 'destroy'])->name('tahun-ajaran.destroy');

    Route::get('/kelas', [KelasController::class, 'index'])->name('kelas.index');
    Route::post('/kelas', [KelasController::class, 'store'])->name('kelas.store');
    Route::patch('/kelas/{kelas}', [KelasController::class, 'update'])->name('kelas.update');
    Route::delete('/kelas/{kelas}', [KelasController::class, 'destroy'])->name('kelas.destroy');

    Route::get('/mapel', [MapelController::class, 'index'])->name('mapel.index');
    Route::post('/mapel', [MapelController::class, 'store'])->name('mapel.store');
    Route::patch('/mapel/{mapel}', [MapelController::class, 'update'])->name('mapel.update');
    Route::delete('/mapel/{mapel}', [MapelController::class, 'destroy'])->name('mapel.destroy');

    Route::post('/jam-pelajaran', [JamPelajaranController::class, 'store'])->name('jam-pelajaran.store');
    Route::patch('/jam-pelajaran/{jamPelajaran}', [JamPelajaranController::class, 'update'])->name('jam-pelajaran.update');
    Route::delete('/jam-pelajaran/{jamPelajaran}', [JamPelajaranController::class, 'destroy'])->name('jam-pelajaran.destroy');

    // Route aliases for English naming
    Route::get('/subjects', [MapelController::class, 'index'])->name('subjects.index');
    Route::post('/subjects', [MapelController::class, 'store'])->name('subjects.store');
    Route::patch('/subjects/{mapel}', [MapelController::class, 'update'])->name('subjects.update');
    Route::delete('/subjects/{mapel}', [MapelController::class, 'destroy'])->name('subjects.destroy');

    Route::post('/time-slots', [JamPelajaranController::class, 'store'])->name('time-slots.store');
    Route::patch('/time-slots/{jamPelajaran}', [JamPelajaranController::class, 'update'])->name('time-slots.update');
    Route::delete('/time-slots/{jamPelajaran}', [JamPelajaranController::class, 'destroy'])->name('time-slots.destroy');

    Route::get('/admin/berita', [BeritaController::class, 'index'])->name('admin.berita.index');
    Route::post('/admin/berita', [BeritaController::class, 'store'])->name('admin.berita.store');
    Route::post('/admin/berita/{berita}', [BeritaController::class, 'update'])->name('admin.berita.update');
    Route::patch('/admin/berita/{berita}', [BeritaController::class, 'update']);
    Route::patch('/admin/berita/{berita}/toggle-pin', [BeritaController::class, 'togglePin'])->name('admin.berita.toggle-pin');
    Route::delete('/admin/berita/{berita}', [BeritaController::class, 'destroy'])->name('admin.berita.destroy');

    // Jadwal Mengajar & Versi Routes
    Route::get('/jadwal', [JadwalController::class, 'index'])->name('jadwal.index');
    Route::post('/jadwal/versi', [JadwalController::class, 'storeVersion'])->name('jadwal.versi.store');
    Route::patch('/jadwal/versi/{jadwalVersi}', [JadwalController::class, 'updateVersion'])->name('jadwal.versi.update');
    Route::patch('/jadwal/versi/{jadwalVersi}/publish', [JadwalController::class, 'publishVersion'])->name('jadwal.versi.publish');
    Route::post('/jadwal/versi/{jadwalVersi}/copy', [JadwalController::class, 'copyVersion'])->name('jadwal.versi.copy');
    Route::delete('/jadwal/versi/{jadwalVersi}', [JadwalController::class, 'destroyVersion'])->name('jadwal.versi.destroy');

    Route::post('/jadwal/versi/{jadwalVersi}/slot', [JadwalController::class, 'storeSlot'])->name('jadwal.slot.store');
    Route::delete('/jadwal/slot/{jadwalSlot}', [JadwalController::class, 'destroySlot'])->name('jadwal.slot.destroy');
    Route::post('/jadwal/versi/{jadwalVersi}/bulk-copy', [JadwalController::class, 'bulkCopySlots'])->name('jadwal.slot.bulk-copy');

    Route::post('/jadwal/generate-sesi', [JadwalController::class, 'generateSesi'])->name('jadwal.generate-sesi');
});

require __DIR__.'/auth.php';
