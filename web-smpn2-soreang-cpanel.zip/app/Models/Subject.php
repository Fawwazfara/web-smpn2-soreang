<?php

namespace App\Models;

class Subject extends Mapel
{
    protected $table = 'mapel';
}

